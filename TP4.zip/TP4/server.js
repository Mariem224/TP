const express = require('express');
const app = express();
const port = 3000;

// Exemple : liste des pizzas
const pizzas = [
{ id: 1, name: "Margherita", price: 8.99 },
{ id: 2, name: "Pepperoni", price: 9.99 },
{ id: 3, name: "Veggie", price: 7.99 }
];

// Route principale
app.get('/', (req, res) => {
res.send('Bienvenue sur le serveur de pizza !');
});

// Route pour obtenir les pizzas
app.get('/pizzas', (req, res) => {
res.json(pizzas);
});

// Démarrer le serveur
app.listen(port, () => {
console.log(`Serveur de pizza en cours d'exécution sur http://localhost:${port}`);
});
app.post('/order', (req, res) => {
    res.send('Commande passée avec succès !');
});