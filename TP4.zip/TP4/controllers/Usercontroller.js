const user= require('../models/User');
const jwt= require('jsonwebtoken');

//inscription du nouvel utilisateur
exports.registeruser  = async (req,res) => {
    const{username, password} =red.body;
}

try{
    const newuser= new user ({ username , password});
    await newuser.save();
    res.status(201).json({message:'utilisateur crée avec succée'})
}catch(error){
    res.status(400).json({message: error.message});
};
//cnx utilisateur existant
exports.loginuser= async (req , res)=> {
    const{username, password} =req.body;
    try{
        const newuser= new user ({ username , password});
        await newuser.save();
        res.status(201).json({message:'utilisateur crée avec succées'})
    }catch(error){
        res.status(400).json({message: error.message});
    
};
//cnx utilisateur existant
exports.loginuser= async (req , res )=> {
    const{username, password} = req.body;

    try
    {

const newliser =new User({username, password )};
await newüser.save();
res.status(201).json(( message: 'Utilisateur créé avec succès' });
}catch (error) {

res.status(480).json([ message: error.message));
    
}
//Connexion d'un utilisateur existant

exports.loginUser =async (req, res)=> (
const { username, password req.body:

try L

const user await üser.findOne((username));

if (lusar) return res.status(484).json((message: Utilisateur non trouvé'));

const sshatch await user.matchPassword(password);

(15shatch) return res.status(400).json((message: Mot de passe incorrect ]

Sénération d'un token Witvoir annese 2wt).

const token jwt.sign({ id: user id), process.env.7WT SECRET, (expiresin: Jed';

res.json((token));

catch (error)

res.status(588).json((message: error.message));